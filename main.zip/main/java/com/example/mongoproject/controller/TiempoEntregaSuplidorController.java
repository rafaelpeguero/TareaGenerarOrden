package com.example.mongoproject.controller;

import com.example.mongoproject.repository.ComponenteRepository;
import com.example.mongoproject.repository.TiempoEntregraSuplidorRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TiempoEntregaSuplidorController {
    private TiempoEntregraSuplidorRepository repository;

    public TiempoEntregaSuplidorController(TiempoEntregraSuplidorRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/tiempoEntrega")
    public String getAllComponente(Model model){
        model.addAttribute("componentes",repository.findAll());
        return "list-componentes";
    }



}
