package com.example.mongoproject.controller;

import com.example.mongoproject.model.Suplidor;
import com.example.mongoproject.model.TiempoEntregaSuplidor;
import com.example.mongoproject.repository.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class GenerarOrdenController {

    private ComponenteRepository repoComponente;
    private DetalleOrdenRepository repoDetalleOrden;
    private MovimientoInventarioRepository repoMovInventario;
    private TiempoEntregraSuplidorRepository repoTiempoEntregaSuplidor;
    private SuplidorRepository repoSuplidor;

    public GenerarOrdenController(ComponenteRepository repoComponente, DetalleOrdenRepository repoDetalleOrden, MovimientoInventarioRepository repoMovInventario, TiempoEntregraSuplidorRepository repoTiempoEntregaSuplidor, SuplidorRepository repoSuplidor) {
        this.repoComponente = repoComponente;
        this.repoDetalleOrden = repoDetalleOrden;
        this.repoMovInventario = repoMovInventario;
        this.repoTiempoEntregaSuplidor = repoTiempoEntregaSuplidor;
        this.repoSuplidor = repoSuplidor;
    }

    // Extraer de '' generarOrden.html ''  --> Metodo GET
    //  Integer cantDeseadaInv
    //  Date fechaDeseada

    //  Funciones de Los Repo a Utilizar ( Aggregate(s) )
    //  repoTiempoEntregaSuplidor.menortiempo("Componente")
    //  repoTiempoEntregaSuplidor.estadoSuplidor("codigoSuplidor")

    //Estado Suplidor

    /*
    boolean EstadoSuplidor(Suplidor suplidor){

       // repoSuplidor.findAll()

    }
    */


    @GetMapping("/generar")
    public String generarOrden(Model model){
        model.addAttribute("componentes",repoComponente.findAll());
        return "generarOrden";
    }

}
