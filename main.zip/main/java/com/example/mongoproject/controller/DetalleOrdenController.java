package com.example.mongoproject.controller;

import com.example.mongoproject.repository.DetalleOrdenRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DetalleOrdenController {
    private DetalleOrdenRepository repository;

    public DetalleOrdenController(DetalleOrdenRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/Detalle_ordenes")
    public String getAllComponente(Model model){
        model.addAttribute("ordenes",repository.findAll());
        return "detalleOrdenes";
    }


}
