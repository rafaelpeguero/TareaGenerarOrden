package com.example.mongoproject.controller;

import com.example.mongoproject.repository.DetalleOrdenRepository;
import com.example.mongoproject.repository.OrdenesRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class OrdenesController {
    private OrdenesRepository repository;

    public OrdenesController(OrdenesRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/ordenes")
    public String getAllOrdenes(Model model){
        model.addAttribute("ordenes",repository.findAll());
        return "Ordenes";
    }


}
