package com.example.mongoproject.controller;

import com.example.mongoproject.model.Componente;
import com.example.mongoproject.repository.ComponenteRepository;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.MatchOperation;
import org.springframework.data.mongodb.core.aggregation.ProjectionOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ComponenteController {
    private ComponenteRepository repository;

    public ComponenteController(ComponenteRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/componentes")
    public String getAllComponente(Model model){
        model.addAttribute("componentes",repository.findAll());
        return "list-componentes";
    }



    @GetMapping("/prueba1")
    public String buscarUnidad(Model model){
        model.addAttribute("componentes",repository.buscarUnidad("unidad3"));
        return "list-componentes";
    }

    @GetMapping("/almacen1")
    public String buscarAlmacen(Model model){
        model.addAttribute("componentes",repository.buscarAlmacen("A-002"));
        return "list-componentes";
    }
    @GetMapping("/almacen")
    public String buscarAlmacen2(Model model){
        model.addAttribute("componentes",repository.buscarAlmacen("A-001"));
        return "list-componentes";
    }

}
