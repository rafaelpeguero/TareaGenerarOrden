package com.example.mongoproject.controller;

import com.example.mongoproject.repository.MovimientoInventarioRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MovimientoInventarioController {

    private MovimientoInventarioRepository repository;

    public MovimientoInventarioController(MovimientoInventarioRepository repositoryMov) {
        this.repository = repositoryMov;
    }

    @GetMapping("/movimientosInv")
    public String getAllMovimientos(Model model){
        model.addAttribute("movimientos", repository.findAll());

        //int tam = repository.findAll().size();
        //System.console().writer().print("Paso");
                //println(tam);

        return "list-movimientos";
    }

    @GetMapping("/movs")
    public String buscarMov(Model model){
        model.addAttribute("movimientos",repository.buscarMov());
        return "list-movimientos";
    }

}
