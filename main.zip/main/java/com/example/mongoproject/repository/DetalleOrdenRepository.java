package com.example.mongoproject.repository;

import com.example.mongoproject.model.Componente;
import com.example.mongoproject.model.DetalleOrden;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DetalleOrdenRepository extends MongoRepository<DetalleOrden,String> {


    //Retorna una Orden Automatica
    @Aggregation( pipeline = {
            "",
            ""
    })
    DetalleOrden generarOrden();

}
