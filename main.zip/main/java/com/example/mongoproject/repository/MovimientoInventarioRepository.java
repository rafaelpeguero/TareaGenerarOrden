package com.example.mongoproject.repository;

import com.example.mongoproject.model.MovimientoInventario;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovimientoInventarioRepository extends MongoRepository<MovimientoInventario,String > {

    @Aggregation(pipeline = {
            "{'$match': {'codigoAlmacen': 'A-002'} }"
    })
    List <MovimientoInventario> buscarMov();


}
