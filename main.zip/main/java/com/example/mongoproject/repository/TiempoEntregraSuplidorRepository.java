package com.example.mongoproject.repository;

import com.example.mongoproject.model.Ordenes;
import com.example.mongoproject.model.TiempoEntregaSuplidor;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TiempoEntregraSuplidorRepository extends MongoRepository<TiempoEntregaSuplidor,String> {

    /*
    @Aggregation(pipeline = {
            "{'$match':{'unidad': ?0 } }"
    })
    TiempoEntregaSuplidor menortiempo(String componente)
        */

}
