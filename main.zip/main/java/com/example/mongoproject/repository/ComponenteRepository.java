package com.example.mongoproject.repository;

import com.example.mongoproject.model.Componente;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ComponenteRepository extends MongoRepository<Componente,String> {


    @Aggregation (pipeline = {
            "{'$match':{'unidad': ?0 } }"
    })
    List<Componente> buscarUnidad(String und);



    @Aggregation(pipeline = {
            "{'$unwind':{path: '$almacenes' }}",
            "{'$match':{'almacenes.codigoAlmacen':?0}}"
            //"{'$match':{'almacenes.codigoAlmance': ?0 } }"
    })
    List<Componente> buscarAlmacen(String alm);

}
