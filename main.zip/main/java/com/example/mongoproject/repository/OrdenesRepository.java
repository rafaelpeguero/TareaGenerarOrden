package com.example.mongoproject.repository;

import com.example.mongoproject.model.DetalleOrden;
import com.example.mongoproject.model.Ordenes;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrdenesRepository extends MongoRepository<Ordenes,String> {

}
