package com.example.mongoproject.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;


@Document( collection = "DetalleOrden")
public class DetalleOrden {
    @Id
    private String id;
    @Field("codigoComponente")
    private String codigoComponente;

    @Field("codigoDetalle")
    private String codigoDetalle;

    @Field("numeroOrden")
    private String numeroOrden;

    @Field("codigoAlmacen")
    private String codigoAlmacen;

    @Field("cantidadComprada")
    private int cantidadComprada;
    @Field("precioCompra")
    private float precioCompra;

    @Field("unidadCompra")
    private String unidadCompra;

    @Field("porcientoDescuento")
    private float porcientoDescuento;

    @Field("montoDetalle")
    private float montoDetalle;


    public DetalleOrden(String codigoComponente, String codigoDetalle, String numeroOrden, String codigoAlmacen, int cantidadComprada, float precioCompra, String unidadCompra, float porcientoDescuento, float montoDetalle) {
        this.codigoComponente = codigoComponente;
        this.codigoDetalle = codigoDetalle;
        this.numeroOrden = numeroOrden;
        this.codigoAlmacen = codigoAlmacen;
        this.cantidadComprada = cantidadComprada;
        this.precioCompra = precioCompra;
        this.unidadCompra = unidadCompra;
        this.porcientoDescuento = porcientoDescuento;
        this.montoDetalle = montoDetalle;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCodigoComponente() {
        return codigoComponente;
    }

    public void setCodigoComponente(String codigoComponente) {
        this.codigoComponente = codigoComponente;
    }

    public String getCodigoDetalle() {
        return codigoDetalle;
    }

    public void setCodigoDetalle(String codigoDetalle) {
        this.codigoDetalle = codigoDetalle;
    }

    public String getNumeroOrden() {
        return numeroOrden;
    }

    public void setNumeroOrden(String numeroOrden) {
        this.numeroOrden = numeroOrden;
    }

    public String getCodigoAlmacen() {
        return codigoAlmacen;
    }

    public void setCodigoAlmacen(String codigoAlmacen) {
        this.codigoAlmacen = codigoAlmacen;
    }

    public int getCantidadComprada() {
        return cantidadComprada;
    }

    public void setCantidadComprada(int cantidadComprada) {
        this.cantidadComprada = cantidadComprada;
    }

    public float getPrecioCompra() {
        return precioCompra;
    }

    public void setPrecioCompra(float precioCompra) {
        this.precioCompra = precioCompra;
    }

    public String getUnidadCompra() {
        return unidadCompra;
    }

    public void setUnidadCompra(String unidadCompra) {
        this.unidadCompra = unidadCompra;
    }

    public float getPorcientoDescuento() {
        return porcientoDescuento;
    }

    public void setPorcientoDescuento(float porcientoDescuento) {
        this.porcientoDescuento = porcientoDescuento;
    }

    public float getMontoDetalle() {
        return montoDetalle;
    }

    public void setMontoDetalle(float montoDetalle) {
        this.montoDetalle = montoDetalle;
    }
}
