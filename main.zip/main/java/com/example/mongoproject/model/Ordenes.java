package com.example.mongoproject.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import java.util.Date;

@Document( collection = "Ordenes")
public class Ordenes {
    @Id
    private String id;
    @Field("numeroOrden")
    private Integer numeroOrden;

    @Field("codigoSuplidor")
    private String codigoSuplidor;

    @Field("fechaOrden")
    private Date fechaOrden;

    @Field("montoTotal")
    private Float montoTotal;

    public Ordenes(Integer numeroOrden, String codigoSuplidor, Date fechaOrden, Float montoTotal) {
        this.numeroOrden = numeroOrden;
        this.codigoSuplidor = codigoSuplidor;
        this.fechaOrden = fechaOrden;
        this.montoTotal = montoTotal;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getNumeroOrden() {
        return numeroOrden;
    }

    public void setNumeroOrden(Integer numeroOrden) {
        this.numeroOrden = numeroOrden;
    }

    public String getCodigoSuplidor() {
        return codigoSuplidor;
    }

    public void setCodigoSuplidor(String codigoSuplidor) {
        this.codigoSuplidor = codigoSuplidor;
    }

    public Date getFechaOrden() {
        return fechaOrden;
    }

    public void setFechaOrden(Date fechaOrden) {
        this.fechaOrden = fechaOrden;
    }

    public Float getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(Float montoTotal) {
        this.montoTotal = montoTotal;
    }
}
