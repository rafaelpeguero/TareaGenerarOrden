package com.example.mongoproject.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;
import java.util.List;

@Document( collection = "MovimientoInventario")
public class MovimientoInventario {
    @Id
    private String id;

    @Field("codigoMovimiento")
    private String codigoMovimiento;

    @Field("fechaMovimiento")
    private Date fechaMovimiento;


    @Field("codigoAlmacen")
    private String codigoAlmacen;

    @Field("tipoMovimiento")
    private String tipoMovimiento;

    @Field("detalle")
    private List<String> detalle;


    public MovimientoInventario(String codigoMovimiento, Date fechaMovimiento, String codigoAlmacen, String tipoMovimiento, List<String> detalle) {
        this.codigoMovimiento = codigoMovimiento;
        this.fechaMovimiento = fechaMovimiento;
        this.codigoAlmacen = codigoAlmacen;
        this.tipoMovimiento = tipoMovimiento;
        this.detalle = detalle;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCodigoMovimiento() {
        return codigoMovimiento;
    }

    public void setCodigoMovimiento(String codigoMovimiento) {
        this.codigoMovimiento = codigoMovimiento;
    }

    public Date getFechaMovimiento() {
        return fechaMovimiento;
    }

    public void setFechaMovimiento(Date fechaMovimiento) {
        this.fechaMovimiento = fechaMovimiento;
    }

    public String getCodigoAlmacen() {
        return codigoAlmacen;
    }

    public void setCodigoAlmacen(String codigoAlmacen) {
        this.codigoAlmacen = codigoAlmacen;
    }

    public String getTipoMovimiento() {
        return tipoMovimiento;
    }

    public void setTipoMovimiento(String tipoMovimiento) {
        this.tipoMovimiento = tipoMovimiento;
    }

    public List<String> getDetalle() {
        return detalle;
    }

    public void setDetalle(List<String> detalle) {
        this.detalle = detalle;
    }
}
