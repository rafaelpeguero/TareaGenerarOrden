package com.example.mongoproject.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document( collection = "Suplidor")
public class Suplidor {
    @Id
    private String id;
}
