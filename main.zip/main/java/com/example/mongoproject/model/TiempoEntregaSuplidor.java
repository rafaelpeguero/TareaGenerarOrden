package com.example.mongoproject.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document( collection = "TiempoEntregaSuplidor")
public class TiempoEntregaSuplidor {
    @Id
    private String id;
}
